﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_Raw_Data
{
   public class Engine
    {
        public int EngineSpeed { get; set; }

        public int EnginePower { get; set; }
    }
}
