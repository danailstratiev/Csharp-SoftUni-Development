﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_Raw_Data
{
   public class Tire
    {
        public int TireAge { get; set; }

        public double TirePressure { get; set; }       
    }
}
