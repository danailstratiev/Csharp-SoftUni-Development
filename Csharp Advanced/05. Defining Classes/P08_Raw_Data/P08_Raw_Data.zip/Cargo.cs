﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_Raw_Data
{
   public class Cargo
    {    
        public int CargoWeight { get; set; }

        public string CargoType { get; set; }
    }
}
