﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
      public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
